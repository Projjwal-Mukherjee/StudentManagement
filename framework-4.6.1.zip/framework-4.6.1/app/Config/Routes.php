<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'LoginController::loginView');
$routes->post('check', 'LoginController::checkExist');

$routes->get('students', 'DashboardController::dashboardView');
$routes->post('logout', 'DashboardController::logout');


$routes->get('deleteStudent/(:num)', 'DashboardController::delete/$1');
$routes->get('students/addStudent','DashboardController::addNew');

$routes->post('students/save','DashboardController::add');
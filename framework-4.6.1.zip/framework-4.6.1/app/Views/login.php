<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Login Page</title>
  <style>
    * {
      box-sizing: border-box;
    }

    body {
      font-family: Arial, sans-serif;
      background: #f4f4f4;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      margin: 0;
    }

    .login-container {
      background-color: #ffffff;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
      width: 90%;
      max-width: 400px;
    }

    .login-form h2 {
      text-align: center;
      margin-bottom: 20px;
    }

    .login-form label {
      display: block;
      margin: 10px 0 5px;
    }

    .login-form input {
      width: 100%;
      padding: 10px;
      margin-bottom: 15px;
      border: 1px solid #ccc;
      border-radius: 5px;
    }

    .login-form button {
      width: 100%;
      padding: 10px;
      background-color: #007bff;
      color: white;
      border: none;
      border-radius: 5px;
      font-size: 16px;
      cursor: pointer;
    }

    .login-form button:hover {
      background-color: #0056b3;
    }
  </style>

</head>

<body id="main-content">
  <div class="login-container">
    <center style="color: red;">
      <?php
      if (session()->getFlashData('error')) {
        echo session()->getFlashData('error');
      }
      ?>
    </center>
    <form class="login-form">
      <span id="err"></span>
      <h2>Login</h2>
      <label for="username">Username</label>
      <input type="text" id="username" name="username" required>

      <label for="password">Password</label>
      <input type="password" id="password" name="password" required>

      <button type="button" id="lgbtn">Login</button>
    </form>
  </div>
</body>

</html>
<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
<!-- DataTables CSS -->
<!-- <link rel="stylesheet" href="https://cdn.datatables.net/1.13.8/css/jquery.dataTables.min.css"> -->
<!-- DataTables JS -->
<!-- <script src="https://cdn.datatables.net/1.13.8/js/jquery.dataTables.min.js"></script> -->

<script type="text/javascript">
  $('#lgbtn').click(function() {
    let base_url = "<?php echo base_url("students") ?>";
    let username = $("#username").val();
    let password = $("#password").val();
    if (username == "" && password == "") {
      $("#err").css("color", "red").html("both fields are required");
    } else if (username == "") {
      $("#err").css("color", "red").html("username required");
    } else if (password == "") {
      $("#err").css("color", "red").html("password required");
    } else {
      $("#err").hide();
      $.ajax({
        type: "POST",
        url: "<?php echo base_url('check') ?>",
        data: {
          username: username,
          password: password
        },
        success: function(data) {
          response = JSON.parse(data);
          if (response.status) {
            $.ajax({
              url: base_url, // Replace with actual target URL
              success: function(html) {
                $('#main-content').html(html); // Inject into main content area
                history.pushState(null, '', base_url); // Change URL without reload
                location.reload();
                history.popState(location.reload());
              }
            });
          } else {
            $("#err").show();
            $("#err").css("color", "red").html(response.message);
          }
        },
        error: function(e) {
          console.log(e);
        }
      });
    }
  });
</script>


<html>
<head>
<title>Dashboard</title>

<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- DataTables CSS -->
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">

<!-- DataTables JS -->
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>

<style>
	#add {
      background-color: #f44336;
      color: white;
      border: none;
      padding: 8px 15px;
      border-radius: 4px;
      cursor: pointer;
      font-size: 14px;
      margin-bottom: 1vh;
    }
</style>

</head>

<body>

<?php
$session = session();
// print_r($session->get('username'));
echo view('header');
?>
<a href="students/addStudent"><button id="add">Add New Student</button></a>
<table id="myTable" class="display">
  <thead>
    <tr>
      <th>Studet ID</th>
      <th>Name</th>
      <th>Class</th>
      <th>Roll</th>
      <th>Section</th>
      <th>Action</th>
    </tr>
  </thead>
  <tbody>
    
     <?php
      foreach($students as $student){
     ?>
     <tr>
      <td><?= $student['studentid'] ?></td>
      <td><?= $student['name'] ?></td>
      <td><?= $student['class'] ?></td>
      <td><?= $student['roll'] ?></td>
      <td><?= $student['sec'] ?></td>
      <td>
      	<a href="<?= site_url('deleteStudent/' . $student['studentid']) ?>" onclick="return confirm('Are you sure? You want to delete <?= $student['name']?>')" style="color: red;">Delete</a>
      </td>
    </tr>
     <?php 
  		}
     ?>
    
  </tbody>
</table>
<script>
  // $(document).ready(function() {
  //   $('#myTable').DataTable();
  // });
	$(document).ready(function(){
		$('#myTable').DataTable();
	})
</script>


<?php
echo view('footer');
?>
</body>
</html>
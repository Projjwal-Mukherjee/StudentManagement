<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title><?= $title ?? 'My Site' ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body, html {
      font-family: Arial, sans-serif;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
    }

    header {
      background-color: #1A237E;
      color: white;
      padding: 15px 20px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
    }

    header h1 {
      font-size: 20px;
    }

    .logout-form button {
      background-color: #f44336;
      color: white;
      border: none;
      padding: 8px 15px;
      border-radius: 4px;
      cursor: pointer;
      font-size: 14px;
    }

    .logout-form button:hover {
      background-color: #d32f2f;
    }

    main {
      flex: 1;
      padding: 20px;
    }

    footer {
      background-color: #f1f1f1;
      text-align: center;
      padding: 10px;
      font-size: 14px;
    }

    @media (max-width: 600px) {
      header {
        flex-direction: column;
        align-items: flex-start;
        gap: 10px;
      }

      main {
        padding: 15px;
      }
    }
  </style>
</head>
<body>

<header>
  <h1>Welcome <?= session()->get('username'); ?></h1>

  <form class="logout-form" action="<?= site_url('logout') ?>" method="post">
    <button type="submit">Logout</button>
  </form>
</header>

<main>

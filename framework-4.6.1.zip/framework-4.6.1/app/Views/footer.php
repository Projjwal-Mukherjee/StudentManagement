</main>

<footer>
  &copy; <?= date('Y') ?> Student Management Website. All rights reserved.
</footer>

</body>
</html>

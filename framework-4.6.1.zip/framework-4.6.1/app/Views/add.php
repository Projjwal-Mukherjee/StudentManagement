<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Responsive Student Form</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f4f4f4;
      margin: 0;
      padding: 20px;
    }

    .form-container {
      max-width: 500px;
      margin: auto;
      background: #fff;
      padding: 25px;
      border-radius: 8px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }

    .form-container h2 {
      text-align: center;
      margin-bottom: 20px;
      color: #1A237E;
    }

    .form-group {
      margin-bottom: 15px;
      display: flex;
      flex-direction: column;
    }

    .form-group2 {
      margin-bottom: 15px;
      display: flex;
      /*flex-direction: column;*/
    }

    .form-group2 label {
      font-weight: bold;
      margin-right: 5px;
      margin-left: 5px;

    }

    .form-group label {
      font-weight: bold;
      margin-bottom: 5px;
    }

    .form-group input {
      padding: 10px;
      border: 1px solid #ccc;
      border-radius: 5px;
      font-size: 16px;
    }

    button {
      width: 100%;
      padding: 12px;
      background-color: #1A237E;
      color: white;
      font-size: 16px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      transition: background 0.3s;
    }

    button:hover {
      background-color: #3949AB;
    }

    @media (max-width: 600px) {
      .form-container {
        padding: 20px 15px;
      }

      .form-group input {
        font-size: 15px;
      }
    }
  </style>
</head>
<body>

  <div class="form-container">
    <h2>Add Student</h2>
    <form action="<?= site_url('students/save') ?>" method="post">
      <div class="form-group">
        <label for="name">Name</label>
        <input type="text" id="name" name="name" required>
      </div>

      <div class="form-group2">
        <label for="class">Class</label>
        <select name="class">
          <option value="1">1</option>
          <option value="2">2</option>
          <option value="3">3</option>
          <option value="4">4</option>
          <option value="5">5</option>
          <option value="6">6</option>
          <option value="7">7</option>
          <option value="8">8</option>
          <option value="9">9</option>
          <option value="10">10</option>
          <option value="11">11</option>
          <option value="12">12</option>        
        </select>

        <label for="sec">Section</label>
        
        <select name="sec">
          <option value="A">A</option>
          <option value="B">B</option>
          <option value="C">C</option>
          <option value="D">D</option>
          <option value="E">E</option>       
        </select>
      </div>

      <div class="form-group" style="margin-bottom: 30px;">
        <label for="roll">Roll</label>
        <input type="number" id="roll" name="roll" required>
      </div>



      <button type="submit">Submit</button>
    </form>
  </div>

</body>
</html>

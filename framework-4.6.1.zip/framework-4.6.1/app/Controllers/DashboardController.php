<?php

namespace App\Controllers;

use App\Models\StudentsModel;

class DashboardController extends BaseController
{
	public function dashboardView()
	{
		try {
			$model = new StudentsModel();
			$data['students'] = $model->findAll();
			return view('dashboard', $data);
		} catch (\Throwable $e) {
			echo $e;
		}
	}

	public function logout()
	{
		try {
			$session = session();
			$session->destroy();
			return redirect()->to('/');
		} catch (\Throwable $e) {
			echo $e;
		}
	}
	public function delete($id)
	{
		echo $id;
		try {
			$model = new StudentsModel();
			$model->delete($id);
			return redirect()->to('/students');
		} catch (\Throwable $e) {
			echo $e;
		}
	}
	public function addNew()
	{
		return view('add');
	}

	public function add()
	{
		try {

			// die();
			if ($_SERVER['REQUEST_METHOD'] == "POST") {
				// echo "coming";
				$model = new StudentsModel();

				$name = $this->request->getPost('name');
				$class = $this->request->getPost('class');
				$roll = $this->request->getPost('roll');
				$sec = $this->request->getPost('sec');

				$model->save([
					'studentid' => null,
					'name' => $name,
					'class' => (string)$class,
					'roll' => (string)$roll,
					'sec' => $sec,
				]);
				$response = ["status" => true, "message" => "success"];
				echo json_encode($response);
				// return redirect()->to('/students');

			} else {
				$response = ["status" => false, "message" => "Invalid form method "];
			}
		} catch (\Throwable $e) {
			echo $e;
		}
	}
}

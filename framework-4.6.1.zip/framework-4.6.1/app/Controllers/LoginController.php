<?php

namespace App\Controllers;

use App\Models\AdminModel;

class LoginController extends BaseController
{
	public function loginView()
	{
		try {
			return view('login');
		} catch (\Exception $e) {
			echo $e;
		}
	}

	public function checkExist()
	{
		try {
			$session = session();
			if ($_SERVER['REQUEST_METHOD'] == "POST") {
				$model = new AdminModel();

				$username = $this->request->getPost('username');
				$password = $this->request->getPost('password');
				$admin = $model->where('username', $username)->first();

				if ($admin) {
					if ($password == $admin['password']) {
						$session->set($admin);
						$response = ["status" => true, "message" => "success"];
						echo json_encode($response);
					} else {
						$response = ["status" => false, "message" => "Invalid credientials"];
						echo json_encode($response);
					}
				} else {
					$response = [
						"status" => false,
						"message" => 'Invalid users'
					];
					echo json_encode($response);
				}
			} else {
				$response = [
					"status" => false,
					"message" => "Method not allowed"
				];
				echo json_encode($response);
			}
		} catch (\Throwable $e) {
			$response = [
				"status" => false,
				"message" => $e
			];
			echo json_encode($response);
		}
	}
}

<?php

namespace App\Controllers;
use App\Models\AdminModel;

class LoginController extends BaseController{
	public function loginView(){
		try {
			return view('login');			
		} catch (Exception $e) {
			echo $e;
		}
	}

	public function checkExist(){
		try {
			$session = session();
			if($_SERVER['REQUEST_METHOD'] == "POST"){
				$model = new AdminModel();

				$username = $this->request->getPost('username'); 
				$password = $this->request->getPost('password'); 
				$admin = $model->where('username',$username)->first();

				if($admin){
					if($password == $admin['password']){
						$session->set($admin);
						print_r($admin);
						return redirect()->to('/students');
					}
					else{
						return redirect()->back()->with('error',"Invalid credientials");
					}
				}
				else{
					return redirect()->back()->with('error',"User not found");
				}
			}	
		}
		catch (\Throwable $e) {
			echo $e;
		}
		
	}
}